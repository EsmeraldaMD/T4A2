package t4a2;

import java.util.Scanner;

/**
 *
 * @author esmer
 */
public class T4A2 {

    public static void main(String[] args) {
        palabra();
    }

    public static void tablas() {
        System.out.println("TABLAS DE MULTIPLICAR");
        int j = 1, i = 1, r = 0;
        while (j < 11) {
            System.out.println("\nTabla de multiplicar del " + j + "\n");
            for (i = i; i < 11; i++) {
                r = j * i;
                System.out.println(j + " x " + i + " = " + r);
            }
            System.out.println("");
            i = 1;
            j++;
        }
    }

    public static void primos() {
        Scanner obj = new Scanner(System.in);
        System.out.print("NUMEROS PRIMOS ENTRE EL 1 Y X\nIngrese un numero cualquiera: ");
        int n = obj.nextInt();
        int p = 0;
        for (int i = 1; i <= n; i++) {
            if (i == 1 || i == 3 || i == 5 || i == 7) {
                p++;
            } else if (i % 2 == 0 || i % 3 == 0 || i % 5 == 0 || i % 7 == 0) {
            } else {
                p++;
            }
        }
        System.out.println("Entre el numero 1 y el numero " + n + " hay " + p + " numeros primos");

    }
    
    public static void pares() {
        Scanner obj = new Scanner(System.in);
        System.out.print("NUMEROS PARES E IMPARES ENTRE EL 1 Y X\nIngrese un numero cualquiera: ");
        int n = obj.nextInt();
        int p = 0, j=0;
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0 ) {
                p++;
            } else {
                j++;
            }
        }
        System.out.println("Entre el numero 1 y el numero " + n + " hay " + p + " numeros pares y "+j+" numeros impares");

    }
    public static void palabra() {
        Scanner obj = new Scanner(System.in);
        System.out.print("PALABRA AL REVES\nIngrese una palabra: ");
        String n = obj.next();
        System.out.println("");
        int y = n.length();
        int i=0, p=0;
        while(i < y){
            p++;
            i++;
        }
        while(p>0){
System.out.print(n.charAt(p));
p--;
  /* for(int i=p ;i>=0;i--){
      System.out.println(n.charAt(i));
   }
        char[] c = n.toCharArray();
        
        
        int i=0, p=0;
        while(i < c.length){
            p++;
            i++;
        }
while(p>c.length){
System.out.print( c[p]);
p--;
}*/
    
    }
}
